import { defineType, defineField } from 'sanity'
import { languages } from '../../languages'

export default defineType({
  name: 'course',
  title: 'Course',
  type: 'document',
  fields: [
    defineField({
      name: 'language',
      title: 'language',
      type: 'string',
      options: {
        list: languages.map((lang) => ({
          title: lang.title,
          value: lang.id,
        })),
      },
      validation: (Rule) => Rule.required(),
    }),

    defineField({
      name: 'title',
      title: 'title',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),

    defineField({
      name: 'description',
      title: 'description',
      type: 'text',
      rows: 3,
    }),

    defineField({ name: 'format', title: 'format', type: 'string' }),
    defineField({ name: 'length', title: 'length', type: 'string' }),

    // jeśli chcesz godzinę — użyj datetime zamiast date
    defineField({ name: 'startDate', title: 'startDate', type: 'date' }),
    defineField({ name: 'endDate', title: 'endDate', type: 'date' }),

    defineField({ name: 'price', title: 'price', type: 'string' }),

    defineField({
      name: 'enrollLink',
      title: 'enrollLink',
      type: 'link',
    }),

    defineField({
      name: 'details',
      title: 'details (rich)',
      type: 'array',
      of: [{ type: 'block' }, { type: 'image' }],
      description: 'Full course description',
    }),

    defineField({
      name: 'whatYoullLearn',
      title: 'whatYoullLearn',
      type: 'array',
      of: [{ type: 'string' }],
    }),

    defineField({
      name: 'curriculum',
      title: 'curriculum',
      type: 'array',
      of: [
        {
          type: 'object',
          name: 'curriculumItem',
          fields: [
            defineField({ name: 'title', title: 'title', type: 'string' }),
            defineField({
              name: 'bullets',
              title: 'bullets',
              type: 'array',
              of: [{ type: 'string' }],
            }),
          ],
        },
      ],
    }),

    defineField({
      name: 'faq',
      title: 'FAQ',
      type: 'array',
      of: [
        {
          type: 'object',
          name: 'faqItem',
          fields: [
            defineField({
              name: 'question',
              title: 'question',
              type: 'string',
            }),
            defineField({ name: 'answer', title: 'answer', type: 'text' }),
          ],
        },
      ],
    }),

    defineField({ name: 'ctaLabel', title: 'ctaLabel', type: 'string' }),
    defineField({ name: 'capacity', title: 'capacity', type: 'number' }),
    defineField({
      name: 'isFeatured',
      title: 'isFeatured',
      type: 'boolean',
      initialValue: false,
    }),
    defineField({ name: 'sortOrder', title: 'sortOrder', type: 'number' }),
  ],
  preview: {
    select: { title: 'title', subtitle: 'language' },
  },
})
