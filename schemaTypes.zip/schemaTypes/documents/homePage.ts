import { defineType, defineField } from 'sanity'
import { languages } from '../../languages'

export default defineType({
  name: 'homePage',
  title: 'Home Page',
  type: 'document',
  fields: [
    defineField({
      name: 'language',
      title: 'language',
      type: 'string',
      options: {
        list: languages.map((lang) => ({ title: lang.title, value: lang.id })),
      },
      validation: (Rule) =>
        Rule.required().custom(async (value, context: any) => {
          if (!value) return 'language is required'
          const docId = context.document?._id || ''
          const client = context.getClient({
            apiVersion: process.env.SANITY_API_VERSION || '2025-01-01',
          })
          const query =
            'count(*[_type == "homePage" && language == $lang && _id != $id])'
          const count = await client.fetch(query, { lang: value, id: docId })
          return count > 0 ? 'Home Page for this language already exists' : true
        }),
    }),

    defineField({ name: 'hero', title: 'hero', type: 'homeHero' }),
    defineField({ name: 'about', title: 'about', type: 'homeAbout' }),
    defineField({ name: 'video', title: 'video', type: 'video' }),

    defineField({
      name: 'testimonials',
      title: 'testimonials',
      type: 'array',
      of: [{ type: 'reference', to: [{ type: 'testimonial' }] }],
    }),

    defineField({
      name: 'authorSection',
      title: 'About Author',
      type: 'homeAuthorSection',
    }),

    defineField({ name: 'courses', title: 'courses', type: 'homeCourses' }),

    defineField({ name: 'cta', title: 'cta', type: 'homeCta' }),
    defineField({ name: 'social', title: 'social', type: 'homeSocial' }),
    defineField({
      name: 'editorial',
      title: 'editorial',
      type: 'homeEditorial',
    }),
  ],
  preview: {
    select: { title: 'language' },
    prepare({ title }) {
      return { title: `Home Page (${title ?? 'no language'})` }
    },
  },
})
