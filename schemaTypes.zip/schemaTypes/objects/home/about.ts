import { defineType, defineField } from 'sanity'

export default defineType({
  name: 'homeAbout',
  title: 'Home About',
  type: 'object',
  fields: [
    defineField({ name: 'title', title: 'title', type: 'string' }),
    defineField({
      name: 'description',
      title: 'description',
      type: 'array',
      of: [{ type: 'block' }],
    }),
    defineField({
      name: 'bullets',
      title: 'bullets',
      type: 'array',
      of: [{ type: 'string' }],
    }),
  ],
})
