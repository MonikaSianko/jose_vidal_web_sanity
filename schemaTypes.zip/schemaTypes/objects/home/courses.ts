import { defineType, defineField } from 'sanity'

export default defineType({
  name: 'homeCourses',
  title: 'Home Courses',
  type: 'object',
  fields: [
    defineField({ name: 'title', title: 'title', type: 'string' }),
    defineField({ name: 'description', title: 'description', type: 'string' }),

    defineField({
      name: 'labels',
      title: 'UI labels',
      type: 'homeCoursesLabels',
    }),

    defineField({
      name: 'items',
      title: 'items',
      type: 'array',
      of: [{ type: 'reference', to: [{ type: 'course' }] }],
    }),
  ],
})
