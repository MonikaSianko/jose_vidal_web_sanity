import { defineType, defineField } from 'sanity'

export default defineType({
  name: 'homeAuthorSection',
  title: 'Home Author Section',
  type: 'object',
  fields: [
    defineField({ name: 'title', title: 'title', type: 'string' }),
    defineField({
      name: 'author',
      title: 'author',
      type: 'reference',
      to: [{ type: 'author' }],
    }),
    // defineField({ name: 'link', title: 'link', type: 'link' }),
  ],
})
