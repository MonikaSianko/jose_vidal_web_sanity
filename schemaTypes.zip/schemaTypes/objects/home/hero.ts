import { defineType, defineField } from 'sanity'

export default defineType({
  name: 'homeHero',
  title: 'Home Hero',
  type: 'object',
  fields: [
    defineField({ name: 'badge', title: 'badge', type: 'string' }),
    defineField({ name: 'title', title: 'title', type: 'string' }),
    defineField({
      name: 'subtitle',
      title: 'subtitle',
      type: 'text',
    }),
    defineField({
      name: 'photo',
      title: 'photo',
      type: 'image',
      options: { hotspot: true },
    }),
    defineField({
      name: 'bgPhoto',
      title: 'background photo',
      type: 'image',
      options: { hotspot: true },
    }),
    defineField({ name: 'primaryCta', title: 'primaryCta', type: 'link' }),
    defineField({ name: 'secondaryCta', title: 'secondaryCta', type: 'link' }),
  ],
})
