import { defineType, defineField } from 'sanity'

export default defineType({
  name: 'homeCta',
  title: 'Home CTA',
  type: 'object',
  fields: [
    defineField({ name: 'title', title: 'title', type: 'string' }),
    defineField({
      name: 'description',
      title: 'description',
      type: 'text',
    }),
    defineField({ name: 'primaryCta', title: 'primaryCta', type: 'link' }),
  ],
})
