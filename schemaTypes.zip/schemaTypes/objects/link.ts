import { defineField, defineType } from 'sanity'

type LinkParent = { type?: 'section' | 'external' | 'phone' | 'email' }

export default defineType({
  name: 'link',
  title: 'Link',
  type: 'object',
  fields: [
    defineField({
      name: 'label',
      title: 'Label',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),

    defineField({
      name: 'type',
      title: 'Type',
      type: 'string',
      initialValue: 'external',
      options: {
        list: [
          { title: 'Section (#about)', value: 'section' },
          { title: 'External URL', value: 'external' },
          { title: 'Phone (tel:)', value: 'phone' },
          { title: 'Email (mailto:)', value: 'email' },
        ],
        layout: 'radio',
      },
      validation: (Rule) => Rule.required(),
    }),

    defineField({
      name: 'sectionId',
      title: 'Section id (without #)',
      type: 'string',
      hidden: ({ parent }) =>
        (parent as LinkParent | undefined)?.type !== 'section',
      validation: (Rule) =>
        Rule.custom((value, ctx) => {
          const parent = ctx.parent as LinkParent | undefined
          if (parent?.type !== 'section') return true
          if (!value) return 'Section id is required'
          if (typeof value === 'string' && value.startsWith('#'))
            return 'Do not include # (write: about, not #about)'
          return true
        }),
    }),

    defineField({
      name: 'url',
      title: 'URL',
      type: 'url',
      hidden: ({ parent }) =>
        (parent as LinkParent | undefined)?.type !== 'external',
      validation: (Rule) =>
        Rule.custom((value, ctx) => {
          const parent = ctx.parent as LinkParent | undefined
          if (parent?.type !== 'external') return true
          return value ? true : 'URL is required'
        }),
    }),

    defineField({
      name: 'phone',
      title: 'Phone',
      type: 'string',
      hidden: ({ parent }) =>
        (parent as LinkParent | undefined)?.type !== 'phone',
      validation: (Rule) =>
        Rule.custom((value, ctx) => {
          const parent = ctx.parent as LinkParent | undefined
          if (parent?.type !== 'phone') return true
          return value ? true : 'Phone is required'
        }),
    }),

    defineField({
      name: 'email',
      title: 'Email',
      type: 'string',
      hidden: ({ parent }) =>
        (parent as LinkParent | undefined)?.type !== 'email',
      validation: (Rule) =>
        Rule.custom((value, ctx) => {
          const parent = ctx.parent as LinkParent | undefined
          if (parent?.type !== 'email') return true
          if (!value) return 'Email is required'
          const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))
          return ok ? true : 'Invalid email'
        }),
    }),

    defineField({
      name: 'newTab',
      title: 'Open in new tab',
      type: 'boolean',
      initialValue: false,
      hidden: ({ parent }) =>
        (parent as LinkParent | undefined)?.type !== 'external',
    }),
  ],
})
