import homePage from './documents/homePage'
import author from './documents/author'
import book from './documents/book'
import course from './documents/course'
import testimonial from './documents/testimonial'
import contact from './documents/contact'
import social from './documents/social'
import header from './documents/header'

// objects (global)
import link from './objects/link'
import imageWithAlt from './objects/imageWithAlt'
import video from './objects/video'
import address from './objects/address'

// objects (home sections)
import homeHero from './objects/home/hero'
import homeAbout from './objects/home/about'
import homeAuthorSection from './objects/home/authorSection'
import homeCourses from './objects/home/courses'
import homeCoursesLabels from './objects/home/labelsCourses'
import homeCta from './objects/home/cta'
import homeSocial from './objects/home/social'
import homeEditorial from './objects/home/editorial'

export const schemaTypes = [
  // documents
  homePage,
  author,
  book,
  course,
  testimonial,
  contact,
  social,
  header,

  // objects (global)
  link,
  imageWithAlt,
  video,
  address,

  // objects (home)
  homeHero,
  homeAbout,
  homeAuthorSection,
  homeCoursesLabels,
  homeCourses,
  homeCta,
  homeSocial,
  homeEditorial,
]
